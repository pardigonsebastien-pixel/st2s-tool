# Sécurité & RGPD

- **HTTPS** obligatoire.
- **Minimisation** des données (seulement ce qui est nécessaire aux séances).
- **Pas de tiers** non autorisé ; exports **locaux** par défaut.
- **Droit à l’effacement** : prévoir un endpoint côté backend (si utilisé) pour purger les données d'un enseignant.
- **Journalisation** : logs techniques non nominatifs (horodatages d’actions).
Mise à jour : 2025-10-13.
