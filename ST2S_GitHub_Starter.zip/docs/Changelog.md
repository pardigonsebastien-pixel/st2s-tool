# Changelog — à compléter

## 2025-10-13
- init: création dépôt et règles de base.
