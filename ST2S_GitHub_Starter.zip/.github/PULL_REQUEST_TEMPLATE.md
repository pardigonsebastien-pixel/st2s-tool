## Objet
<!-- feat/fix + résumé clair -->

## Portée
Fichiers principaux modifiés :

## Impact
- [ ] UI
- [ ] Données
- [ ] Exports
- [ ] Sécurité/RGPD

## Test
Étapes de test en 2 minutes :

## Docs
- [ ] CDC.md
- [ ] Spec_ecran.md
- [ ] Changelog.md (ajout d'une ligne après merge)
