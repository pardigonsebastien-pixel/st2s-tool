---
name: 🐞 Bug
about: Décrire un problème à corriger
---
**Contexte**
Que faisais-tu ?

**Attendu vs Obtenu**
- Attendu :
- Obtenu :

**Étapes pour reproduire**
1.
2.
3.

**Captures/logs**
