---
name: ✨ Feature
about: Décrire une nouvelle fonctionnalité
---
**Objectif métier**

**Périmètre**
Écrans/fichiers concernés :

**Critères d'acceptation (tests 2 min)**
- [ ]
- [ ]
