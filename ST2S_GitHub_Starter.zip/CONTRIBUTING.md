# Contribuer

1. Créer une branche `feat/...` ou `fix/...`.
2. Écrire des commits courts et explicites.
3. Ouvrir une **PR** avec le modèle fourni.
4. Après validation, merger via **Squash & Merge**.
5. Ajouter une **ligne au Changelog** (docs/Changelog.md).
